clc;
clear;
close all;
 
% y(n)= b0 * x(n) + G * x(n-N)
% H(z)= 1+ 0.8*(z^-N)
% h(n)= d(n) + 0.8*d(n-N) 
% N-> 800 samples 
N= 800;

a=[1 zeros(1,N-1) -0.8];
b=[1 0];

figure(1);
zplane(b,a);
title('Pole-Zero plot');

figure(2);
impz(b,a);
title('Impulse response');