import pyaudio
import struct
import math
from matplotlib import pyplot

# f0 = 0      # Normal audio
f0 = 400  # 'Duck' audio

BLOCKLEN = 2048  # Number of frames per block
WIDTH = 2  # Number of bytes per signal value
CHANNELS = 1  # mono
RATE = 32000  # Frame rate (frames/second)
RECORD_SECONDS = 10

pyplot.ion()  # Turn on interactive mode so plot gets updated

fig = pyplot.figure(1)
pyplot.subplot(2, 1, 1)
[g1] = pyplot.plot([], [])

g1.set_xdata(range(BLOCKLEN))
pyplot.setp(g1, color='red')
pyplot.ylim(-32000, 32000)
pyplot.xlim(0, BLOCKLEN)

pyplot.subplot(2, 1, 2)
[g2] = pyplot.plot([], [])

g2.set_xdata(range(BLOCKLEN))
pyplot.setp(g2, color='blue')
pyplot.ylim(-32000, 32000)
pyplot.xlim(0, BLOCKLEN)

p = pyaudio.PyAudio()

stream = p.open(
    format=p.get_format_from_width(WIDTH),
    channels=CHANNELS,
    rate=RATE,
    input=True,
    output=True)

output_block = BLOCKLEN * [0]

# Initialize phase
om = 2 * math.pi * f0 / RATE
theta = 0

# Number of blocks to run for
num_blocks = int(RATE / BLOCKLEN * RECORD_SECONDS)

print('* Recording for %.3f seconds' % RECORD_SECONDS)

# Start loop
for i in range(0, num_blocks):

    # Get frames from audio input stream
    # input_bytes = stream.read(BLOCKLEN)       # BLOCKLEN = number of frames read
    input_bytes = stream.read(BLOCKLEN, exception_on_overflow=False)  # BLOCKLEN = number of frames read

    # Convert binary data to tuple of numbers
    input_tuple = struct.unpack('h' * BLOCKLEN, input_bytes)

    # Go through block
    for n in range(0, BLOCKLEN):
        # No processing:
        # output_block[n] = input_tuple[n]
        # OR
        # Amplitude modulation:
        theta = theta + om
        output_block[n] = int(input_tuple[n] * math.cos(theta))

    # keep theta betwen -pi and pi
    while theta > math.pi:
        theta = theta - 2 * math.pi

    # Convert values to binary data
    output_bytes = struct.pack('h' * BLOCKLEN, *output_block)
    # set the Output values on the graph corresponding to the AM Modulation Output
    g1.set_ydata(output_block)
    g2.set_ydata(input_tuple)
    pyplot.pause(0.001)

    # Write binary data to audio output stream
    stream.write(output_bytes)

print('* Finished')

stream.stop_stream()
stream.close()
p.terminate()

pyplot.ioff()  # Turn off interactive mode
pyplot.close()