import pyaudio
import wave
import struct
import math
from myfunctions import clip16

wavfile = 'author.wav'
# wavfile = 'author.wav'

print('Play the wave file: %s.' % wavfile)

# Open wave file
wf = wave.open(wavfile, 'rb')

# Read wave file properties
RATE = wf.getframerate()  # Frame rate (frames/second)
WIDTH = wf.getsampwidth()  # Number of bytes per sample
LEN = wf.getnframes()  # Signal length
CHANNELS = wf.getnchannels()  # Number of channels

print('The file has %d channel(s).' % CHANNELS)
print('The file has %d frames/second.' % RATE)
print('The file has %d frames.' % LEN)
print('The file has %d bytes per sample.' % WIDTH)

# Vibrato parameters
f0 = 2
W = 0.2  # W = 0 for no effect

BLOCKLEN = 64

output_block = [0] * BLOCKLEN

num_blocks = int(math.floor(LEN / BLOCKLEN))

# Buffer to store past signal values. Initialize to zero.
BUFFER_LEN = 1024  # Set buffer length.
buffer = BUFFER_LEN * [0]  # list of zeros

# Buffer (delay line) indices
kr = 0  # read index
kw = int(0.5 * BUFFER_LEN)  # write index (initialize to middle of buffer)

print('The buffer is %d samples long.' % BUFFER_LEN)

# Open an output audio stream
p = pyaudio.PyAudio()
stream = p.open(format=pyaudio.paInt16,
                channels=1,
                rate=RATE,
                input=False,
                output=True)

print('* Playing...')
n=0
input_bytes = wf.readframes(BLOCKLEN)
# Loop through wave file
while len(input_bytes) >= BLOCKLEN * WIDTH:



    # Convert string to number
    input_tuple = struct.unpack('h' * BLOCKLEN, input_bytes)

    # Go through block
    for k in range(0, BLOCKLEN):
        # Get previous and next buffer values (since kr is fractional)
        kr_prev = int(math.floor(kr))
        frac = kr - kr_prev  # 0 <= frac < 1
        kr_next = kr_prev + 1
        if kr_next == BUFFER_LEN:
            kr_next = 0

        # Compute output value using interpolation
        y0 = (1 - frac) * buffer[kr_prev] + frac * buffer[kr_next]
        y1 = int(clip16(y0))
        output_block[k] = y1
        # Update buffer
        buffer[kw] = input_tuple[k]

        # Increment read index
        kr = kr + 1 + W * math.sin(2 * math.pi * f0 * n / RATE)
        # Note: kr is fractional (not integer!)

        # Ensure that 0 <= kr < BUFFER_LEN
        if kr >= BUFFER_LEN:
            # End of buffer. Circle back to front.
            kr = kr - BUFFER_LEN

        # Increment write index
        kw = kw + 1
        if kw == BUFFER_LEN:
            # End of buffer. Circle back to front.
            kw = 0

        n=n+1

    # Clip and convert output value to binary string
    output_bytes = struct.pack('h' * BLOCKLEN, *output_block)

    # Write output to audio stream
    stream.write(output_bytes)

    # Get sample from wave file
    input_bytes = wf.readframes(BLOCKLEN)

print('* Finished')

stream.stop_stream()
stream.close()
p.terminate()
wf.close()