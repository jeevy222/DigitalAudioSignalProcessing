# Complex AM is performed on the microphone input and the output is saved to a wav file as well as played to speaker

import pyaudio
import struct
import wave
import numpy as np
from scipy import signal
from math import pi


def clip16(value):
    # Clipping for 16 bits
    if value > 32767:
        value = 32767
    elif value < -32768:
        value = -32768
    else:
        value = value
    return value


fs = 16000
CHANNELS = 1
DURATION = 5  # number of seconds to run the AM on Mic input
fr = 8

# complex filter
order = 7  # order of the filter
[b_lpf, a_lpf] = signal.ellip(order, 0.2, 50, 0.48)

imaginary = 1j
x = [imaginary ** i for i in range(0, order + 1)]
a = [0 * l for l in range(0, order + 1)]
b = [0 * l for l in range(0, order + 1)]

for k in range(0, order + 1):
    b[k] = b_lpf[k] * x[k]
    a[k] = a_lpf[k] * x[k]

filter_states = np.zeros(order)

# pyaudio object
p = pyaudio.PyAudio()
# open a stream to read and write audio
stream = p.open(rate=fs,
                channels=CHANNELS,
                format=pyaudio.paInt16,
                input=True,
                output=True)

# Wave file
wavfile = 'recorded_complex_AM.wav'
wf = wave.open(wavfile, 'w')  # wf : wave file
print('Using microphone input for complex AM, the output will be saved as %s while being played to headphones' % wavfile)
wf.setnchannels(CHANNELS)  # one channel (mono)
wf.setsampwidth(2)  # two bytes per sample (16 bits per sample)
wf.setframerate(fs)  # samples per second

N = fs * DURATION  # total number of samples for given sampling frequency and signal duration
for k in range(0, int(N / fr)):
    string = stream.read(fr, exception_on_overflow=False)
    input_block = struct.unpack('h' * fr, string)
    output_block, states = signal.lfilter(b, a, input_block, zi=filter_states)

    freq = 400
    g = [1j for i in range(0, order + 1)]
    temp = [0 for i in range(0, fr)]

    for counter in range(0, fr):
        g[counter] = (output_block[counter] * np.e **
                      (imaginary * 2 * pi * freq * (k * 8 + counter) / fs)).real
        temp[counter] = int(g[counter].real)
        output = struct.pack('h', temp[counter])
        wf.writeframesraw(output)
        stream.write(output)

# close the wave file, stop the audio stream to speakers / headphones, terminate the pyaudio object
wf.close()
stream.stop_stream()
stream.close()
p.terminate()
