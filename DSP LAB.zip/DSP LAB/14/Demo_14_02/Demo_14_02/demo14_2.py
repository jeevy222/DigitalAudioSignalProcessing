import pyaudio, struct
import wave, math
import numpy as np
from scipy import signal
import matplotlib.pyplot as plt

wavfile = 'filterBlocking.wav'

# Read the wave file properties
CHANNELS = 1  # Number of channels
RATE = 8000  # Sampling rate (frames/second)
DURATION = 10  # Signal length
WIDTH = 2  # Number of bytes per sample

BLOCKLEN = 1000
MAXVALUE = 2 ** 15 - 1  # Maximum allowed output signal value (because WIDTH = 2)

output_wavfile = wavfile[:-4] + '_output_blocking_corrected.wav'
wf = wave.open(output_wavfile, 'wb')  # wave file
wf.setframerate(RATE)
wf.setsampwidth(WIDTH)
wf.setnchannels(CHANNELS)

x = [0 for i in range(BLOCKLEN)]
y = [0 for i in range(BLOCKLEN)]

plt.ion()  # Turn on interactive mode so plot gets updated

fig = plt.figure(1)
fig.subplots_adjust(hspace=.5)

plt.subplot(211)
line, = plt.plot(x, color='blue')
plt.ylim(-32000, 32000)  # set y-axis limits
plt.xlim(0, BLOCKLEN)  # set x-axis limits
plt.xlabel('Time')
plt.title('Input Signal')

plt.subplot(212)
line_, = plt.plot(y, color='red')
plt.ylim(-32000, 32000)  # set y-axis limits
plt.xlim(0, BLOCKLEN)  # set x-axis limits
plt.xlabel('Time')
plt.title('Filtered Signal')

# Difference equation coefficients
b0 = 0.008442692929081
b2 = -0.016885385858161
b4 = 0.008442692929081
b = [b0, 0.0, b2, 0.0, b4]

# a0 =  1.000000000000000
a1 = -3.580673542760982
a2 = 4.942669993770672
a3 = -3.114402101627517
a4 = 0.757546944478829
a = [1.0, a1, a2, a3, a4]

p = pyaudio.PyAudio()

# Open audio stream
stream = p.open(
    format=pyaudio.paInt16,
    channels=CHANNELS,
    rate=RATE,
    input=True,
    output=True)

# Number of blocks in wave file
NumBlocks = int(DURATION * RATE / BLOCKLEN)

ORDER = 4  # filter is fourth order
states = np.zeros(ORDER)

f = [0 for n in range(BLOCKLEN)]



for i in range(NumBlocks):

    x = stream.read(BLOCKLEN, exception_on_overflow=False)
    # Convert binary string to tuple of numbers
    input_tuple = struct.unpack('h' * BLOCKLEN, x)
    line.set_ydata(input_tuple)

    # filter
    y, states = signal.lfilter(b, a, input_tuple, zi=states)

    # clipping
    y = np.clip(y, -MAXVALUE, MAXVALUE)

    # convert to integer
    y = y.astype(int)
    line_.set_ydata(y)

    # Convert output value to binary data
    binary_data = struct.pack('h' * BLOCKLEN, *y)

    plt.pause(0.001)
    plt.draw()
    # Write binary data to audio stream
    stream.write(binary_data)

    # Write binary data to output wave file
    wf.writeframes(binary_data)

# Save spectrum to a pdf file
fig.savefig("Filter Blocking output plot.pdf")
print("Output saved to %s file.",wavfile)
print('* Finished')

stream.stop_stream()
stream.close()
p.terminate()
plt.close()
# Close wavefiles
wf.close()
