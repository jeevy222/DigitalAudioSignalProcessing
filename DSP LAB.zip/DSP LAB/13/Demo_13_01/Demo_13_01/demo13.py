# Modified plot_microphone_input_spectrum.py to get AM output and plot both input and output signals

import pyaudio
import struct
import wave
from matplotlib import pyplot as plt
import math
import numpy as np

WIDTH = 2  # bytes per sample
CHANNELS = 1  # mono
RATE = 8000  # Sampling rate (samples/second)
BLOCKSIZE = 1024  # length of block (samples)
DURATION = 10  # Duration (seconds)

f0 = 400  # Frequency for Amplitude modulation (Hz)

BLOCKSIZE = 1024  # Number of frames per block

# Open audio stream
p = pyaudio.PyAudio()
stream = p.open(
    format=p.get_format_from_width(WIDTH),
    channels=CHANNELS,
    rate=RATE,
    input=True,
    output=True)

y = [0 for n in range(0, BLOCKSIZE)]

# Number of blocks in wave file
NumBlocks = int(DURATION * RATE / BLOCKSIZE)

# Initialize phase
om = 2 * math.pi * f0 / RATE
theta = 0

DBscale = True

fig = plt.figure(1)
fig.subplots_adjust(hspace=.5)

plt.subplot(211)
if DBscale:
    plt.ylim(0, 150)
else:
    plt.ylim(0, 20 * RATE)

# Frequency axis (Hz)
plt.xlim(0, 0.5 * RATE)  # set x-axis limits
plt.xlabel('Frequency (Hz)')
f = [n * float(RATE) / BLOCKSIZE for n in range(BLOCKSIZE)]

line, = plt.plot([], [], color='blue')  # Create empty line
line.set_xdata(f)  # x-data of plot (frequency)

plt.subplot(212)
if DBscale:
    plt.ylim(0, 150)
else:
    plt.ylim(0, 20 * RATE)

# Frequency axis (Hz)
plt.xlim(0, 0.5 * RATE)  # set x-axis limits
plt.xlabel('Frequency (Hz)')
f = [n * float(RATE) / BLOCKSIZE for n in range(BLOCKSIZE)]

line_, = plt.plot([], [], color='red')  # Create empty line
line_.set_xdata(f)  # x-data of plot (frequency)

# Save output to Wave file
wf = wave.open('myWaveFileMicrophoneAM.wav', 'w')  # wf : wave file
wf.setnchannels(CHANNELS)  # one channel (mono)
wf.setsampwidth(WIDTH)  # four bytes per sample (32 bits per sample)
wf.setframerate(RATE)  # samples per second


# Go through wave file
for i in range(0, NumBlocks):

    input_string = stream.read(BLOCKSIZE, exception_on_overflow=False)
    # Convert binary string to tuple of numbers
    input_tuple = struct.unpack('h' * BLOCKSIZE, input_string)

    X_fft = np.fft.fft(input_tuple)
    # Update y-data of plot
    if DBscale:
        line.set_ydata(20 * np.log10(abs(X_fft)))
    else:
        line.set_ydata(abs(X_fft))

    # Go through block
    for n in range(0, BLOCKSIZE):
        # Amplitude modulation  (f0 Hz cosine)
        theta = theta + om
        y[n] = int(input_tuple[n] * math.cos(theta))

    # keep theta betwen -pi and pi
    while theta > math.pi:
        theta = theta - 2 * math.pi

    Y_fft = np.fft.fft(y)
    # Convert values to binary string
    output_string = struct.pack('h' * BLOCKSIZE, *y)
    # Update y-data of plot
    if DBscale:
        line_.set_ydata(20 * np.log10(abs(Y_fft)))
    else:
        line_.set_ydata(abs(Y_fft))

    plt.pause(0.001)
    plt.draw()
    # Write output to wave file
    wf.writeframesraw(output_string)
    stream.write(output_string)

# Save spectrum to a pdf file
fig.savefig("Microphone AM output FFT spectrum.pdf")
print(" save the output to myWaveFileMicrophoneAM.wav file.")
print('* Finished')
plt.close()
wf.close()
stream.stop_stream()
stream.close()
p.terminate()
