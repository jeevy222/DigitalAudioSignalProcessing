# Demo 7
# Record from microphone, filter the signal,
# and play the output signal on the loud speaker.

import pyaudio
import struct
from math import cos, pi
import wave


def clip16(x):
    # Clipping for 16 bits
    if x > 32767:
        x = 32767
    elif x < -32768:
        x = -32768
    else:
        x = x
    return (x)


WIDTH = 2  # Number of bytes per sample
CHANNELS = 1  # mono
RATE = 16000  # Sampling rate (frames/second)
DURATION = 6  # duration of processing (seconds)

N = DURATION * RATE  # N : Number of samples to process

f0 = 600  # Frequency in Hertz
p = pyaudio.PyAudio()

# Open audio stream
wf = wave.open('Demo07_jeevy_Modified.wav', 'w')
wf.setnchannels(CHANNELS)
wf.setsampwidth(WIDTH)
wf.setframerate(RATE)

wf2 = wave.open('Demo07_jeevy_Original.wav', 'w')
wf2.setnchannels(CHANNELS)
wf2.setsampwidth(WIDTH)
wf2.setframerate(RATE)
stream = p.open(
    format=p.get_format_from_width(WIDTH),
    channels=CHANNELS,
    rate=RATE,
    input=True,
    output=True)

print('* The Show is started')
for n in range(0, N):
    # Get one frame from audio input (microphone)
    input_bytes = stream.read(1, exception_on_overflow=False)

    # Convert binary data to tuple of numbers
    input_tuple = struct.unpack('h', input_bytes)

    # Convert one-element tuple to number
    x0 = input_tuple[0]
    # Write frame to demo_original.wav
    wf2.writeframes(struct.pack('h', int(clip16(x0))))

    output_value = int(clip16(x0 * cos(2 * pi * f0 * n / RATE)))
    # output_value = int(clip16(x0))   # Bypass filter (listen to input directly)

    # Convert output value to binary data
    output_bytes = struct.pack('h', output_value)

    # Write binary data to audio stream
    wf.writeframes(output_bytes)
    # Write frame to demo_modified.wav
    stream.write(output_bytes)

print('* Finished Bro')

wf.close()
stream.stop_stream()
stream.close()
p.terminate()
