# hp_karplus_strong.py
# Implements Karplus Strong algorithm with circular buffer
# Sound of plucked string

import pyaudio
import wave
import struct
from myfunctions import clip16
from random import normalvariate
import numpy as np


# signal information
RATE     = 8000
WIDTH    = 2
CHANNELS = 1

duration = 2

# Karplus-Strong paramters
K = 0.99
N = 60

a = list(np.zeros(N-1))
a.insert(0,1)
a.append(-K/2)
a.append(-K/2)
b = 1
print("Value of filters: {} {}".format(a[N], a[N+1]))


gain = 10000    # gain for using with normal distribution function

# input - standard normal distrubuted random sequence
x = [gain*normalvariate(0,1) for i in range(N)]
xzeros = list(np.zeros(int(duration*RATE) - N))
x.extend(xzeros)

# num_samples = duration*RATE
num_samples = len(x)

# Create a buffer to store past values. Initialize to zero.
BUFFER_LEN = N+1   # N+1 is kept because we want max delay of N+1 samples
buffer = [ 0 for i in range(BUFFER_LEN) ]


p = pyaudio.PyAudio()
stream = p.open(
    format      = pyaudio.paInt16,
    channels    = CHANNELS,
    rate        = RATE,
    input       = False,
    output      = True )

k = 0       # buffer index (circular index)
overflowCounter = 0

print("* Start *")

for i in range(num_samples):

    # Convert string to number
    input_value = x[i]

    # KS-> a0*y0 = b0*x0 - K/2*y60 - K/2*y61
    if(k == N):
        output_value = b * input_value - a[N] * buffer[0] - a[N+1] * buffer[k]
    else:
        output_value = b * input_value - a[N] * buffer[k+1] - a[N+1] * buffer[k]

    # Update buffer
    buffer[k] = output_value

    # Increment buffer index
    k = k + 1
    if k >= BUFFER_LEN:
        # The index has reached the end of the buffer. Circle the index back to the front.
        k = 0

    # used overflowCounter to see how many times amplitude overflow occurs, so as to safely set the normal distribution gain
    output_value, overflowCounter = clip16(output_value, overflowCounter)
    output_string = struct.pack('h', int(output_value))

    stream.write(output_string)

print("* Finished *")
print("Amplitude overflow occured {} times. ".format(overflowCounter))

stream.stop_stream()
stream.close()
p.terminate()