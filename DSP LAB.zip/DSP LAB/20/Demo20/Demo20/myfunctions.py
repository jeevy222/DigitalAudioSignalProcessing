
def clip16( x , counter):    
    # Clipping for 16 bits
    if x > 32767:
        x = 32767
        counter = counter + 1
    elif x < -32768:
        x = -32768
        counter = counter + 1
    else:
        x = x        
    return (x,counter)

def clip16_warning( x ):    
    # Clipping for 16 bits
    if x > 32767:
        x = 32767
        print('positive clipping')
    elif x < -32768:
        x = -32768
        print('negative clipping')
    else:
        x = x        
    return(x)
