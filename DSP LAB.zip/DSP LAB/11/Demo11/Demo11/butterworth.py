import pyaudio
import struct
import wave
import matplotlib.pyplot as plt


# Clipping function
def clip16(x):
    # Clipping for 16 bits
    if x > 32767:
        x = 32767
    elif x < -32768:
        x = -32768
    else:
        x = x
    return x


# The output has been tested on various like sin_mono.wav, author.wav and myWaveFile.wav files included in the folder
wavefile = 'author.wav'
filtered_wave_file = wavefile[:-4] + '_filtered.wav'

# Open wave file (should be mono channel)
wf = wave.open(wavefile, 'rb')
wff = wave.open(filtered_wave_file, 'wb')

# Read the wave file properties
num_channels = wf.getnchannels()  # Number of channels
RATE = wf.getframerate()  # Sampling rate (frames/second)
signal_length = wf.getnframes()  # Signal length
width = wf.getsampwidth()  # Number of bytes per sample

wff.setnchannels(num_channels)  # one channel (mono)
wff.setsampwidth(width)  # four bytes per sample (32 bits per sample)
wff.setframerate(RATE)  # samples per second

BLOCKLEN = 1000  # Blocksize to display at a single time

# Difference equation coefficients
b0 = 0.008442692929081
b2 = -0.016885385858161
b4 = 0.008442692929081

# a0 =  1.000000000000000
a1 = -3.580673542760982
a2 = 4.942669993770672
a3 = -3.114402101627517
a4 = 0.757546944478829

# Initialization
x1 = 0.0
x2 = 0.0
x3 = 0.0
x4 = 0.0
y1 = 0.0
y2 = 0.0
y3 = 0.0
y4 = 0.0

wav_data = []  # wave file data written will be appended to this list and will be plotted after filter is applied

# Get first frame from wave file
input_string = wf.readframes(1)

# Apply butterworth bandpass filter to the wave file and save it as a separate wave file for further plotting
while len(input_string) > 0:
    # Convert string to number
    input_tuple = struct.unpack('h', input_string)  # One-element tuple
    input_value = input_tuple[0]  # Number

    # Set input to difference equation
    x0 = input_value

    # Difference equation
    y0 = b0 * x0 + b2 * x2 + b4 * x4 - a1 * y1 - a2 * y2 - a3 * y3 - a4 * y4

    # y(n) = b0 x(n) + b2 x(n-2) + b4 x(n-4) - a1 y(n-1) - a2 y(n-2) - a3 y(n-3) - a4 y(n-4)

    # Delays
    x4 = x3
    x3 = x2
    x2 = x1
    x1 = x0
    y4 = y3
    y3 = y2
    y2 = y1
    y1 = y0

    # Compute output value
    output_value = int(clip16(y0))  # Integer in allowed range

    # Convert output value to binary string
    output_string = struct.pack('h', output_value)

    wff.writeframesraw(output_string)

    # Get next frame from wave file
    input_string = wf.readframes(1)

wf.close()
wff.close()

# Open wave file
wf = wave.open(wavefile, 'rb')
wff = wave.open(filtered_wave_file, 'rb')

# Read wave file properties
RATE = wf.getframerate()  # Frame rate (frames/second)
WIDTH = wf.getsampwidth()  # Number of bytes per sample
LEN = wf.getnframes()  # Signal length
CHANNELS = wf.getnchannels()  # Number of channels

# properties of filtered wave file
RATE_ = wff.getframerate()  # Frame rate (frames/second)
WIDTH_ = wff.getsampwidth()  # Number of bytes per sample
LEN_ = wff.getnframes()  # Signal length
CHANNELS_ = wff.getnchannels()  # Number of channels

print('Unfiltered file: %s' % wavefile)
print('The file has %d channel(s).' % CHANNELS)
print('The file has %d frames/second.' % RATE)
print('The file has %d frames.' % LEN)
print('The file has %d bytes per sample.' % WIDTH)
print()
print('Filtered wave file using Butterworth bandpass filter: %s' % filtered_wave_file)
print('The file has %d channel(s).' % CHANNELS_)
print('The file has %d frames/second.' % RATE_)
print('The file has %d frames.' % LEN_)
print('The file has %d bytes per sample.' % WIDTH_)

BLOCKLEN = 1000  # Blocksize

# Get block of samples from wave file
binary_data = wf.readframes(BLOCKLEN)
binary_data_ = wff.readframes(BLOCKLEN)

# Set up plotting...

plt.ion()  # Turn on interactive mode so plot gets updated

fig = plt.figure(figsize=(8, 8))
fig.subplots_adjust(hspace=.5)

signal_block = struct.unpack('h' * BLOCKLEN, binary_data)
signal_block_ = struct.unpack('h' * BLOCKLEN, binary_data_)

plt.subplot(121)
line, = plt.plot(signal_block, color='blue')
plt.ylim(-32000, 32000)  # set y-axis limits
plt.xlim(0, BLOCKLEN)  # set x-axis limits
plt.xlabel('Time')
plt.title('Input Signal')

plt.subplot(122)
line_, = plt.plot(signal_block_, color='red')
plt.ylim(-32000, 32000)  # set y-axis limits
plt.xlim(0, BLOCKLEN)  # set x-axis limits
plt.xlabel('Time')
plt.title('Filtered Signal')

# Open the audio output stream
p = pyaudio.PyAudio()
PA_FORMAT = p.get_format_from_width(WIDTH)

Frames_Per_Buffer = 256

stream = p.open(
    format=PA_FORMAT,
    channels=CHANNELS,
    rate=RATE,
    input=False,
    output=True,
    frames_per_buffer=Frames_Per_Buffer)

while len(binary_data) >= BLOCKLEN * WIDTH & len(binary_data_) >= BLOCKLEN:
    # Convert binary data to number sequence (tuple)
    signal_block = struct.unpack('h' * BLOCKLEN, binary_data)
    signal_block_ = struct.unpack('h' * BLOCKLEN, binary_data_)

    line.set_ydata(signal_block)
    line_.set_ydata(signal_block_)
    plt.pause(0.0000001)
    plt.draw()
    # Write binary string to audio output stream
    stream.write(binary_data, BLOCKLEN)

    # Get block of samples from wave file
    binary_data = wf.readframes(BLOCKLEN)
    binary_data_ = wff.readframes(BLOCKLEN)

stream.stop_stream()
stream.close()
p.terminate()

wf.close()
wff.close()